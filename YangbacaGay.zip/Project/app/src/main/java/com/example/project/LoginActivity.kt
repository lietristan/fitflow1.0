package com.example.project

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.project.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    //Bikin kata"Klik disini jika belum punya akun" pindah ke halaman register(1)
    lateinit var binding: ActivityLoginBinding
    lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
            finish()
        }
        //(1)
        fun onClick(v: View?) {
            if (v != null) {
                when (v.id) {
                    R.id.btn_login -> {
                        val pindahTempat = Intent(this, MainActivity::class.java)
                        startActivity(pindahTempat)
                    }
                }
            }
        }
    }
}


