package com.example.project

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import androidx.appcompat.app.AppCompatActivity
import com.example.project.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {
    lateinit var binding: ActivityRegisterBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegister.setOnClickListener {

            var email = binding.edtEmailRegister.text.toString()
            var password = binding.edtPasswordRegister.text.toString()
// Ketentuan Register kalau register ga diisi email
            if(email.isEmpty()){
                binding.edtEmailRegister.error = "Email harus diisi"
                binding.edtEmailRegister.requestFocus()
                return@setOnClickListener
            }
// Ketentuan kalau ga ada huruf @
            if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
                binding.edtEmailRegister.error = "Email tidak vaid"
                binding.edtEmailRegister.requestFocus()
                return@setOnClickListener
            }
// Ketentuan kalau ga isi password
            if(password.isEmpty()){
                binding.edtPasswordRegister.error = "Password harus diisi"
                binding.edtPasswordRegister.requestFocus()
                return@setOnClickListener
            }
// Ketentuan password harus 8 huruf
            //kusus 8 karakter
            if(password.length < 8){
                    binding.edtPasswordRegister.error = "Password harus 8 karakter"
                    binding.edtPasswordRegister.requestFocus()
                    return@setOnClickListener
            }

        }
        binding.tvRegister.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }

    }
// Buat Toast

}